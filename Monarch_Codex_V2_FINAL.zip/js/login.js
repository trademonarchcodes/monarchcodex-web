
const SUPABASE_URL="https://avaworleivncevaoqeny.supabase.co";
const SUPABASE_ANON_KEY="sb_publishable_OZCDmpzZ1-pvN1rfTGqrpw_JatYPjIh";
const supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
function showAlert(msg,type){const el=document.getElementById("alert");el.textContent=msg;el.className="alert "+type;el.style.display="block";}
document.getElementById("loginForm").addEventListener("submit",async(e)=>{
 e.preventDefault();
 const btn=document.getElementById("submitBtn");const orig=btn.textContent;btn.disabled=true;btn.textContent="Logging in...";
 const email=document.getElementById("email").value.trim();const password=document.getElementById("password").value;
 try{
  const {data,error}=await supabaseClient.auth.signInWithPassword({email,password});if(error)throw error;
  showAlert("Login successful! Checking role...","success");
  // profiles has NO email column - only role
  const {data:profile}=await supabaseClient.from("profiles").select("role").eq("id",data.user.id).single();
  const role=profile?.role||"member";
  const isMainAdmin=email.toLowerCase()==="trademonarchofficial@gmail.com";
  if(role==="admin"||role==="super_admin"||isMainAdmin||role.includes("admin")){
    setTimeout(()=>window.location.replace("admin.html"),800);
  }else{
    setTimeout(()=>window.location.replace("dashboard.html"),600);
  }
 }catch(err){showAlert(err.message,"error");btn.disabled=false;btn.textContent=orig;}
});
async function resetPass(){const email=prompt("Enter email:");if(!email)return;const {error}=await supabaseClient.auth.resetPasswordForEmail(email,{redirectTo:location.origin+"/login.html"});if(error)alert(error.message);else alert("Reset link sent");}
