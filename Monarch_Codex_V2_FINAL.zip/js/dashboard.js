
const SUPABASE_URL="https://avaworleivncevaoqeny.supabase.co";
const SUPABASE_ANON_KEY="sb_publishable_OZCDmpzZ1-pvN1rfTGqrpw_JatYPjIh";
const supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
let currentUser=null, currentProfile=null, selectedPackage=null, selectedPayment=null;

async function init(){
  const {data:{user}}=await supabaseClient.auth.getUser();
  if(!user){document.getElementById("appLoading").classList.add("hidden");document.getElementById("authError").classList.remove("hidden");return;}
  currentUser=user;
  const {data:profile}=await supabaseClient.from("profiles").select("*").eq("id",user.id).single();
  currentProfile=profile;
  document.getElementById("appLoading").classList.add("hidden");
  document.getElementById("appShell").classList.remove("hidden");
  document.getElementById("sidebarMemberName").textContent=profile.full_name;
  document.getElementById("sidebarMemberUID").textContent=profile.uid;
  document.getElementById("sidebarMemberInitial").textContent=profile.full_name[0];
  document.getElementById("displayUsername").textContent=profile.display_username||profile.full_name.split(" ")[0];
  loadOverview();
  loadPackages();
  loadTransactions();
  loadReferrals();
  loadProfile();
}

function switchSection(name){
  document.querySelectorAll(".dashboard-section").forEach(s=>s.classList.add("hidden"));
  document.getElementById(name+"Section")?.classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.remove("active"));
  document.querySelector(`[data-section="${name}"]`)?.classList.add("active");
  document.getElementById("topbarTitle").textContent=name.charAt(0).toUpperCase()+name.slice(1);
}

document.querySelectorAll(".nav-item").forEach(btn=>{
  btn.addEventListener("click",()=>switchSection(btn.dataset.section));
});
document.getElementById("logoutBtn")?.addEventListener("click",async()=>{await supabaseClient.auth.signOut();location.href="login.html";});

async function loadOverview(){
  const {data:investments}=await supabaseClient.from("investments").select("amount,status").eq("user_id",currentUser.id);
  const totalInv=investments?.filter(i=>i.status==="approved").reduce((s,i)=>s+Number(i.amount),0)||0;
  const {data:trans}=await supabaseClient.from("transactions").select("amount,type").eq("user_id",currentUser.id);
  const earnings=trans?.filter(t=>t.type==="earning"||t.type==="referral_bonus").reduce((s,i)=>s+Number(i.amount),0)||0;
  const balance=currentProfile.balance||0;
  document.getElementById("balance").textContent="$"+Number(balance).toFixed(2);
  document.getElementById("totalInvested").textContent="$"+totalInv.toFixed(2);
  document.getElementById("totalEarnings").textContent="$"+earnings.toFixed(2);
  document.getElementById("refEarnings").textContent="$"+earnings.toFixed(2);
  document.getElementById("earningsTotal").textContent="$"+earnings.toFixed(2);
  const kycBadge=document.getElementById("kycStatusBadge");
  if(currentProfile.kyc_status==="approved"){kycBadge.innerHTML='<span style="background:#00c851;color:#fff;padding:4px 10px;border-radius:20px;font-size:11px">KYC Approved - Active</span>';document.getElementById("kycStatusText").textContent="KYC: Approved — You can invest";}
  else if(currentProfile.kyc_status==="rejected"){kycBadge.innerHTML='<span style="background:#ff4444;color:#fff;padding:4px 10px;border-radius:20px;font-size:11px">KYC Rejected</span>';}
  else{kycBadge.innerHTML='<span style="background:#D4AF37;color:#000;padding:4px 10px;border-radius:20px;font-size:11px">KYC Pending</span>';}
}

async function loadPackages(){
  const {data:pkgs}=await supabaseClient.from("packages").select("*").order("amount");
  const list=document.getElementById("packagesList");
  if(!pkgs||!list)return;
  list.innerHTML="";
  pkgs.forEach(p=>{
    const div=document.createElement("div");
    div.className="payment-method-card";
    div.innerHTML=`<strong>${p.name}</strong><br><span style="color:var(--gold)">$${p.amount}</span><br><small style="color:#888">${p.profit_percent}% target</small>`;
    div.onclick=()=>{selectedPackage=p;document.querySelectorAll("#packagesList .payment-method-card").forEach(c=>c.classList.remove("selected"));div.classList.add("selected");loadPaymentMethods();};
    list.appendChild(div);
  });
}

async function loadPaymentMethods(){
  const {data:methods}=await supabaseClient.from("payment_details").select("*").eq("active",true);
  const grid=document.getElementById("paymentMethods");
  if(!methods||!grid)return;
  grid.innerHTML="<h4 style='color:var(--gold);grid-column:1/-1'>Select Payment Method</h4>";
  methods.forEach(m=>{
    const div=document.createElement("div");
    div.className="payment-method-card";
    const name=m.payment_type==="bank"?`${m.bank_name} - ${m.account_name}`:`${m.crypto_name} ${m.crypto_network}`;
    div.innerHTML=`<strong style="font-size:12px">${name}</strong><br><small style="color:#777;word-break:break-all">${(m.wallet_address||m.account_number||'').substring(0,20)}...</small>`;
    div.onclick=()=>{
      selectedPayment=m;
      document.querySelectorAll("#paymentMethods .payment-method-card").forEach(c=>c.classList.remove("selected"));
      div.classList.add("selected");
      showPaymentDetail(m);
    };
    grid.appendChild(div);
  });
}

function showPaymentDetail(m){
  const panel=document.getElementById("paymentDetailPanel");
  panel.classList.remove("hidden");
  if(m.payment_type==="bank"){
    panel.innerHTML=`<h4 style="color:var(--gold)">Bank Transfer Details</h4><div style="margin-top:10px"><p><small>Bank:</small> <strong>${m.bank_name}</strong></p><p><small>Account Name:</small> <strong>${m.account_name}</strong></p><p><small>Account Number:</small> <strong>${m.account_number}</strong> <button class="copy-btn" onclick="navigator.clipboard.writeText('${m.account_number}')">Copy</button></p><div style="margin-top:12px;background:rgba(212,175,55,0.1);border:1px solid var(--border);padding:10px;border-radius:8px"><small>Amount to Pay:</small><br><strong style="color:var(--gold);font-size:18px">$${selectedPackage?.amount||0}</strong><br><small>Pay exact amount and upload receipt</small></div></div>`;
  }else{
    panel.innerHTML=`<h4 style="color:var(--gold)">${m.crypto_name} - ${m.crypto_network}</h4><p style="word-break:break-all;color:#fff;margin-top:8px">${m.wallet_address} <button class="copy-btn" onclick="navigator.clipboard.writeText('${m.wallet_address}')">Copy</button></p><div style="margin-top:12px;background:rgba(212,175,55,0.1);border:1px solid var(--border);padding:10px;border-radius:8px"><small>Amount:</small><br><strong style="color:var(--gold);font-size:18px">$${selectedPackage?.amount||0} in ${m.crypto_name}</strong></div>`;
  }
  document.getElementById("receiptArea").classList.remove("hidden");
}

document.getElementById("submitInvestmentBtn")?.addEventListener("click",async()=>{
  if(!selectedPackage||!selectedPayment){alert("Select package and payment method");return;}
  const file=document.getElementById("receiptFile").files[0];
  if(!file){alert("Upload receipt");return;}
  const fileName=`${currentUser.id}/${Date.now()}_${file.name}`;
  const {data:upload,error:upErr}=await supabaseClient.storage.from("receipts").upload(fileName,file);
  if(upErr){alert(upErr.message);return;}
  const {data:urlData}=supabaseClient.storage.from("receipts").getPublicUrl(fileName);
  const {error}=await supabaseClient.from("investments").insert({user_id:currentUser.id,package_name:selectedPackage.name,amount:selectedPackage.amount,payment_method:selectedPayment.payment_type,receipt_url:urlData.publicUrl,status:"pending"});
  if(error){alert(error.message);return;}
  // Transaction
  await supabaseClient.from("transactions").insert({user_id:currentUser.id,type:"investment",amount:selectedPackage.amount,display_amount:`+$${selectedPackage.amount}`,description:`Investment ${selectedPackage.name}`});
  alert("Investment submitted! Admin will verify receipt.");
  loadOverview();
});

async function loadTransactions(){
  const {data:trans}=await supabaseClient.from("transactions").select("*").eq("user_id",currentUser.id).order("created_at",{ascending:false}).limit(50);
  const list=document.getElementById("transactionsList");
  if(!trans||!list)return;
  list.innerHTML="";
  if(!trans.length){list.innerHTML="<p style='color:#777'>No transactions yet</p>";return;}
  trans.forEach(t=>{
    const div=document.createElement("div");
    const isPlus=t.amount>0||t.display_amount?.startsWith("+");
    div.style="display:flex;justify-content:space-between;padding:10px;border-bottom:1px solid rgba(255,255,255,0.05);font-size:13px";
    div.innerHTML=`<span>${t.description||t.type} <small style="color:#777">${new Date(t.created_at).toLocaleDateString()}</small></span><strong style="color:${isPlus?'#4ee58a':'#ff7777'}">${t.display_amount||(isPlus?'+':'-')+'$'+Math.abs(t.amount)}</strong>`;
    list.appendChild(div);
  });
}

async function loadReferrals(){
  const {data:refs}=await supabaseClient.from("profiles").select("full_name,uid,created_at,status").eq("referred_by",currentUser.id);
  document.getElementById("totalReferrals").textContent=refs?.length||0;
  document.getElementById("activeReferrals").textContent=refs?.filter(r=>r.status==="active").length||0;
  document.getElementById("referralCode").textContent=currentProfile.referral_code||"";
  document.getElementById("referralLink").value=location.origin+"/register.html?ref="+(currentProfile.referral_code||"");
  const list=document.getElementById("referralsList");
  if(list){list.innerHTML="";refs?.forEach(r=>{const d=document.createElement("div");d.style="padding:8px;border-bottom:1px solid rgba(255,255,255,0.05);display:flex;justify-content:space-between";d.innerHTML=`<span>${r.full_name} <small>${r.uid}</small></span><span style="color:#4ee58a">${r.status}</span>`;list.appendChild(d);});}
}

async function loadProfile(){
  const info=document.getElementById("profileInfo");
  if(!info)return;
  info.innerHTML=`<p><strong>Name (NIN):</strong> ${currentProfile.full_name} (cannot be changed)</p><p><strong>Phone:</strong> ${currentProfile.phone} (cannot be changed)</p><p><strong>UID:</strong> ${currentProfile.uid}</p><p><strong>Referral Code:</strong> ${currentProfile.referral_code}</p><p><strong>Status:</strong> ${currentProfile.status} | KYC: ${currentProfile.kyc_status}</p>`;
  // Username cooldown
  const lastChanged=currentProfile.username_last_changed?new Date(currentProfile.username_last_changed):null;
  const now=new Date();
  const diff=lastChanged? (now-lastChanged)/(1000*60*60*24):10;
  const cd=document.getElementById("usernameCooldown");
  if(diff<7){cd.textContent=`You can change username again in ${(7-diff).toFixed(1)} days`;document.getElementById("saveUsernameBtn").disabled=true;}
  else{cd.textContent="You can change username now";document.getElementById("saveUsernameBtn").disabled=false;}
}

document.getElementById("saveUsernameBtn")?.addEventListener("click",async()=>{
  const newName=document.getElementById("newDisplayUsername").value.trim();
  if(!newName){alert("Enter username");return;}
  const lastChanged=currentProfile.username_last_changed?new Date(currentProfile.username_last_changed):null;
  const now=new Date();
  if(lastChanged && (now-lastChanged)/(1000*60*60*24)<7){alert("You can only change username every 7 days");return;}
  const {error}=await supabaseClient.from("profiles").update({display_username:newName,username_last_changed:now.toISOString()}).eq("id",currentUser.id);
  if(error){alert(error.message);return;}
  alert("Username updated!");location.reload();
});

document.getElementById("copyReferralCodeBtn")?.addEventListener("click",()=>{navigator.clipboard.writeText(document.getElementById("referralCode").textContent);alert("Copied!");});
document.getElementById("copyReferralLinkBtn")?.addEventListener("click",()=>{navigator.clipboard.writeText(document.getElementById("referralLink").value);alert("Link copied!");});

// KYC Submit
document.getElementById("submitKYCBtn")?.addEventListener("click",async()=>{
  const country=document.getElementById("kycCountry").value.trim();
  const state=document.getElementById("kycState").value.trim();
  const city=document.getElementById("kycCity").value.trim();
  const address=document.getElementById("kycAddress").value.trim();
  const nin=document.getElementById("kycNIN").value.trim();
  const front=document.getElementById("kycNINFront").files[0];
  const back=document.getElementById("kycNINBack").files[0];
  const selfie=document.getElementById("kycSelfie").files[0];
  if(!country||!state||!city||!address||!nin||!front||!back||!selfie){alert("Fill all KYC fields and uploads");return;}
  // Upload files
  async function uploadFile(file,path){const {data,error}=await supabaseClient.storage.from("kyc").upload(`${currentUser.id}/${path}_${Date.now()}_${file.name}`,file);if(error)throw error;const {data:url}=supabaseClient.storage.from("kyc").getPublicUrl(data.path);return url.publicUrl;}
  try{
    const frontUrl=await uploadFile(front,"front");
    const backUrl=await uploadFile(back,"back");
    const selfieUrl=await uploadFile(selfie,"selfie");
    const {error}=await supabaseClient.from("profiles").update({country,state,city,address,nin_number:nin,nin_front_url:frontUrl,nin_back_url:backUrl,selfie_url:selfieUrl,kyc_status:"pending",status:"kyc_under_review"}).eq("id",currentUser.id);
    if(error)throw error;
    alert("KYC submitted! Admin will verify each section (name, NIN card, selfie).");
    location.reload();
  }catch(e){alert(e.message);}
});

// Withdrawal
document.getElementById("submitWithdrawalBtn")?.addEventListener("click",async()=>{
  const amount=Number(document.getElementById("withdrawAmount").value);
  const accName=document.getElementById("withdrawAccountName").value.trim();
  const accNum=document.getElementById("withdrawAccountNumber").value.trim();
  const bank=document.getElementById("withdrawBankName").value.trim();
  if(!amount||amount<5){alert("Min $5");return;}
  if(!accName||!accNum||!bank){alert("Fill account details - must match NIN name");return;}
  if(accName.toLowerCase()!==currentProfile.full_name.toLowerCase()){if(!confirm("Account name does NOT match your NIN name ("+currentProfile.full_name+"). Withdrawal must bear your original names, no third party. Continue?"))return;}
  const {error}=await supabaseClient.from("withdrawals").insert({user_id:currentUser.id,amount,account_name:accName,account_number:accNum,bank_name:bank,status:"pending"});
  if(error){alert(error.message);return;}
  await supabaseClient.from("transactions").insert({user_id:currentUser.id,type:"withdrawal",amount:-amount,display_amount:`-$${amount}`,description:"Withdrawal request"});
  alert("Withdrawal requested! Min $5, will be processed.");
});

init();
