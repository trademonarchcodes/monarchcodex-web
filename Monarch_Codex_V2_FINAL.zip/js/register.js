
const SUPABASE_URL="https://avaworleivncevaoqeny.supabase.co";
const SUPABASE_ANON_KEY="sb_publishable_OZCDmpzZ1-pvN1rfTGqrpw_JatYPjIh";
const supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
function showAlert(m,t){const el=document.getElementById("alert");el.textContent=m;el.className="alert "+t;el.style.display="block";}
function genUID(){return "MONARCH"+Math.floor(100000+Math.random()*900000);}
function genRef(){return "MONARCH"+Math.random().toString(36).substring(2,8).toUpperCase();}
document.getElementById("registerForm").addEventListener("submit",async(e)=>{
 e.preventDefault();
 const btn=document.getElementById("submitBtn");btn.disabled=true;btn.textContent="Creating...";
 const fullName=document.getElementById("fullName").value.trim();
 const phone=document.getElementById("phone").value.trim();
 const email=document.getElementById("email").value.trim();
 const password=document.getElementById("password").value;
 const referralInput=document.getElementById("referralCode").value.trim();
 try{
  const {data,error}=await supabaseClient.auth.signUp({email,password});
  if(error)throw error;
  const user=data.user;
  let referredBy=null;
  if(referralInput){
    const {data:refProf}=await supabaseClient.from("profiles").select("id").eq("referral_code",referralInput).single();
    if(refProf) referredBy=refProf.id;
  }
  const uid=genUID();
  const refCode=genRef();
  const {error:profErr}=await supabaseClient.from("profiles").insert({
    id:user.id, full_name:fullName, phone:phone, uid:uid, referral_code:refCode,
    referred_by:referredBy, role:"member", status:"pending_kyc", display_username:fullName.split(" ")[0]
  });
  if(profErr)throw profErr;
  showAlert("Account created! Please check email to verify, then login to complete KYC.","success");
  setTimeout(()=>window.location.replace("login.html"),2000);
 }catch(err){showAlert(err.message,"error");btn.disabled=false;btn.textContent="Create Account";}
});
